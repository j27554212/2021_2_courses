<!DOCTYPE html>
<meta charset="utf-8">
<title>Redirecting to https://youtu.be/b2HeubvZMaU</title>
<meta http-equiv="refresh" content="0; URL=https://youtu.be/b2HeubvZMaU">
<link rel="canonical" href="https://youtu.be/b2HeubvZMaU">

