This is a big image of a small whale:

![A whale](whale.jpg)
