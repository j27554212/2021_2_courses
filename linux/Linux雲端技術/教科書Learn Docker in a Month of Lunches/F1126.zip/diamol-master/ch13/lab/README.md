# DIAMOL Chapter 13 Lab - Sample Solution

Deploy the stack:

```
docker stack deploy -c image-gallery.yml image-gallery
```

> Browse to http://localhost (or from a remote machine if you're using Windows containers)

You'll see the app (your image will be different):

![](solution.png)
