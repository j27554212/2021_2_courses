docker run -d -P -v "$(pwd)/config/dev:/config-override" ch18-iotd
