#!/bin/bash
#Author: @likegeeks
if [ "mokhtar" \> "Mokhtar" ] 
then
echo "String1 is greater than the second string"
else
echo "String1 is less than the second string"
fi