#!/bin/bash
name="Mokhtar"
age=35
total=16.5
echo $name  #prints Mokhtar
echo $age   #prints 35
echo $total #prints 16.5