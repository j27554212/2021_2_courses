#!/bin/bash
echo "You are using $(basename $0)"
echo "Hello $*"
exit 0
