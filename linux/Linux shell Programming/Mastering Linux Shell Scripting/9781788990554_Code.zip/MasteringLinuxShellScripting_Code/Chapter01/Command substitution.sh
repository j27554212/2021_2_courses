#!/bin/bash
cur_dir=`pwd`
echo $cur_dir